<?php
 include("database.php");

 //Delete code
 if(!empty($_GET['delid']))
{ 
	$did = $_GET['delid'];
	$sel = mysqli_query($conn,"select image from tbl_crudwithgrid where id='$did'");
	$arr = mysqli_fetch_assoc($sel);
	$oldimage = $arr['image'];
	
	
	mysqli_query($conn,"delete from tbl_crudwithgrid where id='$did'");
	unlink("image/".$oldimage);
	header("location:index.php?msg=delete");
	
}
?>
<!DOCTYPE html>
<html>
<head>
<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>
</head>
<body>
<div style="display:flex">
<h1 style="color:green">Employee Management</h1>  
<a href="addDetails.php" style="margin-left:6px;margin-top:30px;text-decoration:none;font-size:20px;background-color:green;color:white;padding:10px;">Add Details</a>
</div>

<h1 style="margin:0;color:green">Employee List</h1>

<table id="customers">
  <tr>
    <th>S.No</th>
    <th>Name </th>
    <th>Email</th>
    <th>Gender</th>
    <th>Profile Image</th>
    <th>DOB</th>
    <th>Salary</th>
    <th>Action</th>
  </tr>
  <tr>
  <?php
              $sel = mysqli_query($conn,"select * from tbl_crudwithgrid");     

 //   pagination end
              $sn=1;
              while($arr = mysqli_fetch_assoc($sel))
              {
              ?>
                <tr>
                  <td><?=$sn;?></td>
                  <td><?=$arr['fname'];?></td>
                  <td><?=$arr['email'];?></td>
                  <td><?=$arr['gender'];?></td>
                  <td><img src="image/<?=$arr['image'];?>" height="30px" width="60px"></td>
                  <td><?=$arr['dob'];?></td>
                  <td><?=$arr['salary'];?></td>
                  
                  <td><a href="editDetails.php?editid=<?=$arr['id'];?>" class="btn btn-info">Edit</a> 
                  <a href="?delid=<?=$arr['id']?>">Delete</a></td>
                </tr>
              <?php
              $sn++;
              }
            ?>
  </tr>
  
</table>

</body>
</html>


