<?php
  // Database connection
  include("database.php");
  
extract($_POST);
if(isset($sub))
{
  $fn = $_FILES['profile_img']['name'];
  $tmp = $_FILES['profile_img']['tmp_name'];
  
  $arr = explode('.',$fn);
  $ext = end($arr);
  
  if($ext == "jpg" || $ext=="jpeg" || $ext=="png")
  {
    if($_FILES['profile_img']['size'] > 100000)
    {
      $msg = "File is more than 2mb";
    }else{
        $fnn = rand().$fn;
        if(mysqli_query($conn,"insert into tbl_crudwithgrid(fname,email,gender,image,dob,salary)values('$f_name','$email','$gender','$fnn','$dob','$salary')"))
        {
          move_uploaded_file($tmp,"image/".$fnn);
          header("location:index.php?msg=added");
        }
        else
        {
          header("location:addDetails.php?msg=error");
        }
    }
  }
  else
  {
    header("location:addDetails.php?msg=imgerror");
  }

}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Task Manager</title>
	<style>
	body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
}

.myForm {
    display: grid;
    grid-template-columns: [labels] auto [controls] 1fr;
    grid-auto-flow: row;
    grid-gap: .8em;
    background: #eee;
    padding: 1.2em;
  }
  .myForm > label  {
    grid-column: labels;
    grid-row: auto;
  }
  .myForm > input,
  .myForm > textarea,
  .myForm > button {
    grid-column: controls;
    grid-row: auto;
    border: none;
    padding: 1em;
  }
	</style>
</head>
<body>
    <div class="container">
       <h1>Add Details</h1>
         <a href="info.php">Back to profile</a>
         <?php
         if(isset($msg)){
          echo $msg;
         }
          ?>
       <form class="myForm" method="post" name="profile_form"  enctype="multipart/form-data" onsubmit="return validateForm()">
            <label for="customer_name">First Name </label>
            <input type="text" name="f_name" id="f_name" onkeyup="validatename()" required>
            <label for="customer_name">Email</label>-
            <input type="email" name="email" id="email" onkeyup="validatelname()" required>
            <label for="customer_name">Gender</label>
            <input type="text" name="gender" id="gender" required>
            <label for="customer_name">Profile Image </label>
            <input type="file" name="profile_img" id="profile_img" required>
            <label for="customer_name">DOB</label>
            <input type="date" name="dob" id="dob" required>
            <label for="customer_name">Salary</label>
            <input type="text" name="salary" id="salary" required>
            <input type="submit" name="sub">
      </form>
    </div>
<script>
 function validatename()
  {
    var name=document.getElementById('f_name');
	  name.value=name.value.replace(/[^a-zA-Z]+/, '');
  }
  function validatelname()
  {
    var name=document.getElementById('l_name');
	  name.value=name.value.replace(/[^a-zA-Z]+/, '');
  }
  function validatenumber()
  {
    var phone=document.getElementById('phone_num');
	  phone.value=phone.value.replace(/[^0-9]+/, '');
  }

  function validateForm()
  {
    let name = document.forms["profile_form"]["f_name"].value;
    let lname = document.forms["profile_form"]["l_name"].value;
    let phone = document.forms["profile_form"]["phone_num"].value;

    if (name == "") {
      alert("Name must be filled out");
      return false;
    }else{
      validatename();
    }

    if (lname == "") {
      alert("Last Name must be filled out");
      return false;
    }else{
        validatelname();
    }

    if (phone == "") {
      alert("phone Number must be filled out");
      return false;
    }else{
        validatenumber();
    }
  
    
  }
</script>
</body>
</html>
