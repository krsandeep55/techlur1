<?php
  // Database connection
  $conn = mysqli_connect("localhost", "root", "", "techlurDB");


?>