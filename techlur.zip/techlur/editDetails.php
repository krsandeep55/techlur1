<?php
include("database.php");
 
$eid = $_GET['editid'];

// category info get by id
$sel = mysqli_query($conn,"select * from tbl_crudwithgrid where id='$eid'");
$arr = mysqli_fetch_assoc($sel);
echo $oldimage=$arr['image'];
// die();
//print_r($chk1);

extract($_POST);
if(isset($sub))
{
 $fn = $_FILES['profile_img']['name'];
 $tmp = $_FILES['profile_img']['tmp_name'];
 
 if(empty($fn))
 {
  //update only candidate name
   
   if(mysqli_query($conn,"update tbl_crudwithgrid set fname='$f_name',email='$email',gender='$gender',dob='$dob',salary='$salary' where id='$eid'"))
   {
     header("location:index.php?msg=update");
   }

 }
 else
 {
  //update both cname and cimg
   $arr = explode('.',$fn);
   $ext = end($arr);

   if($ext=="jpeg"||$ext=="jpg"||$ext=="png")
   {
     $fnn = rand().$fn;

      if(mysqli_query($conn,"update tbl_crudwithgrid set fname='$f_name',email='$email',image='$fnn',gender='$gender',dob='$dob',salary='$salary' where id='$eid'"))
      {
       move_uploaded_file($tmp,"image/".$fnn);
       unlink("image/".$oldimage);
       header("location:index.php?msg=update");
      }
      else
      {
       header("location:editinfo.php?editid=$eid&&msg=error");
      }
     
   }
   else
   {
     header("location:editinfo.php?editid=$eid&&msg=imgerror");
   }
 }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="style.css">
    <title>Update</title>
	<style>
	body {
    font-family: Arial, sans-serif;
    background-color: #f2f2f2;
}

.myForm {
    display: grid;
    grid-template-columns: [labels] auto [controls] 1fr;
    grid-auto-flow: row;
    grid-gap: .8em;
    background: #eee;
    padding: 1.2em;
  }
  .myForm > label  {
    grid-column: labels;
    grid-row: auto;
  }
  .myForm > input,
  .myForm > textarea,
  .myForm > button {
    grid-column: controls;
    grid-row: auto;
    border: none;
    padding: 1em;
  }
	</style>
</head>
<body>
    <div class="container">
       <h1>Edit Details</h1>
         <a href="index.php">Back to profile</a>
       <form class="myForm" method="post" enctype="multipart/form-data">
            <label for="customer_name">Full Name </label>
            <input type="text" name="f_name" id="f_name" value="<?=$arr['fname'];?>" required>
            <label for="customer_name">Email </label>
            <input type="email" name="email" id="email" value="<?=$arr['email'];?>" required>
            <label for="customer_name">Phone Number </label>
            <input type="text" name="gender" id="gender" value="<?=$arr['gender'];?>" required>
            <label for="customer_name">Profile Image </label>
            <input type="file" name="profile_img" id="profile_img" value="<?= $oldimage;?>">
            <label for="customer_name">DOB</label>
            <input type="date" name="dob" id="dob" value="<?=$arr['dob'];?>" required>
            <label for="customer_name">Salary</label>
            <input type="text" name="salary" id="salary" value="<?=$arr['salary'];?>" required>
            <input type="submit" name="sub">
      </form>
    </div>

</body>
</html>
